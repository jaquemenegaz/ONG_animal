<?php

namespace App\Models;

use CodeIgniter\Model;

class AnimalModel extends Model
{
    // definimos a tabela correspondente ao model
    protected $table          = 'animal';
    // definimos qual coluna na tabela `usuarios`corresponde à chave primária
    protected $primaryKey     = 'id_animal';

    protected $returnType     = 'App\Entities\Animal';

    //protected $useSoftDeletes = true;
    protected $allowedFields  = ['nome_animal','caracteristicas', 'raca', 'foto_animal'];
    //protected $useTimestamps  = true;

    // definimos as regras de validação
    protected $validationRules    = [
        'nome_animal'     => 'required',
        'caracteristicas' => 'required',
        'raca'            => 'required',
        'foto_animal'     => 'required'
    ];

    // definimos as mensagens de validação
    protected $validationMessages = [
        'nome_animal' =>[
            'required' => 'Compo de preenchimento obrigatório.'
        ],
        'caracteristicas' => [
            'required'   => 'Campo de preenchimento obrigatório.'
        ],
        'raca' => [
            'required'   => 'Campo de preenchimento obrigatório.'
        ],
        'foto_animal' => [
            'required'   => 'Campo de preenchimento obrigatório.'
        ],
    ];

}