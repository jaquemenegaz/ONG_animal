<?php

namespace App\Models;

use CodeIgniter\Model;

class DenunciaModel extends Model
{
    // definimos a tabela correspondente ao model
    protected $table          = 'denuncia';
    // definimos qual coluna na tabela `usuarios`corresponde à chave primária
    protected $primaryKey     = 'id_denuncia';

    protected $returnType     = 'App\Entities\Denuncia';

    //protected $useSoftDeletes = true;
    protected $allowedFields  = ['endereco','motivo', 'foto_denuncia'];
    //protected $useTimestamps  = true;

    // definimos as regras de validação
    protected $validationRules    = [
        'endereco'             => 'required',
        'motivo'        => 'required',
        'foto_denuncia' => 'required'
    ];

    // definimos as mensagens de validação
    protected $validationMessages = [
        'endereco' => [
            'required'   => 'Campo de preenchimento obrigatório.'
        ],
        'motivo' => [
            'required'   => 'Campo de preenchimento obrigatório.'
        ],
        'foto_denuncia' => [
            'required'   => 'Campo de preenchimento obrigatório.'
        ],
        
    ];

}