<?php

namespace App\Models;

use CodeIgniter\Model;

class UsuarioModel extends Model
{
    // definimos a tabela correspondente ao model
    protected $table          = 'usuario';
    // definimos qual coluna na tabela `usuarios`corresponde à chave primária
    protected $primaryKey     = 'id_usuario';

    protected $returnType     = 'App\Entities\Usuario';

    //protected $useSoftDeletes = true;
    protected $allowedFields  = ['email', 'senha'];
   
    // definimos as regras de validação
    protected $validationRules    = [
        'email'             => 'required|min_length[3]',
        'senha'              => 'required|min_length[11]|max_length[11]|is_unique[usuario.senha]'
    ];

    // definimos as mensagens de validação
    protected $validationMessages = [
        'email' => [
            'required'   => 'Campo de preenchimento obrigatório.',
            'min_length' => 'O campo precisa ter pelo menos 3 caracteres.'
        ],
        'senha' => [
            'required'            => 'Campo de preenchimento obrigatório.',
            'min_length'          => 'O campo precisa ter pelo menos 11 caracteres.',
            'max_length'          => 'O campo deve ter no máximo 11 caracteres.'
        ],

    ];

}