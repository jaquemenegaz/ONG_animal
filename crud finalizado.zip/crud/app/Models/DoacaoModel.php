<?php

namespace App\Models;

use CodeIgniter\Model;

class DoacaoModel extends Model
{
    // definimos a tabela correspondente ao model
    protected $table          = 'doacao';
    // definimos qual coluna na tabela `usuarios`corresponde à chave primária
    protected $primaryKey     = 'id_doacao';

    protected $returnType     = 'App\Entities\Doacao';

    //protected $useSoftDeletes = true;
    protected $allowedFields  = ['senha','email','id_produto','id_usuario'];
    //protected $useTimestamps  = true;
    //protected $createdField   = 'criado_em';
    //protected $updatedField   = 'atualizado_em';
    //protected $deletedField   = 'removido_em';

    // definimos as regras de validação
    protected $validationRules    = [
        'senha'             => 'required|min_length[3]'
    ];

    // definimos as mensagens de validação
    protected $validationMessages =
     [
        'senha' => [
            'required'   => 'Campo de preenchimento obrigatório.',
            'min_length' => 'O campo precisa ter pelo menos 3 caracteres.'
        ],
    ];

}

    /*class UserModel extends Model
    {
        protected $table = 'usuario';
        protected $allowedFields = ['nome', 'cpf'];
    }*/