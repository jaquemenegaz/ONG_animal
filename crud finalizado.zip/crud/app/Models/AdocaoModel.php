<?php

namespace App\Models;

use CodeIgniter\Model;

class AdocaoModel extends Model
{
    // definimos a tabela correspondente ao model
    protected $table          = 'adocao';
    // definimos qual coluna na tabela `usuarios`corresponde à chave primária
    protected $primaryKey     = 'id_adocao';

    protected $returnType     = 'App\Entities\Adocao';

    //protected $useSoftDeletes = true;
    protected $allowedFields  = ['telefone', 'email', 'endereco', 'id_animal', 'id_usuario'];
    //protected $useTimestamps  = true;

    // definimos as regras de validação
    protected $validationRules    = [
        'telefone'             => 'required',
        'email'        => 'required',
        'endereco' => 'required',
        'id_animal' => 'required',
        'id_usuario' => 'required'
    ];

    // definimos as mensagens de validação
    protected $validationMessages = [
        'telefone' => [
            'required'   => 'Campo de preenchimento obrigatório.'
        ],
        'email' => [
            'required'   => 'Campo de preenchimento obrigatório.'
        ],
        'endereco' => [
            'required'   => 'Campo de preenchimento obrigatório.'
        ],
        'id_animal' => [
            'required'   => 'Campo de preenchimento obrigatório.'
        ],
        'id_usuario' => [
            'required'   => 'Campo de preenchimento obrigatório.'
        ]
    ];

}