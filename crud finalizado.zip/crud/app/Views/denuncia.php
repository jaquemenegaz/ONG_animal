<!DOCTYPE html>

<html lang="pt-br">
  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"
        integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
        <link rel="stylesheet" href= "<?= base_url('css/ong.css') ?>">

    <title>Animal ONG</title>
  </head>
  <body>
      <div class="container ">
        <div class="row" id="cabecalho">
          <div class="col-sm-4 col-md-3 col-lg-3 col-3 ">
            <img class="w-75" src="<?= base_url('img/logo_ong.PNG') ?>" alt="logo do usuário">
          </div>
  
          <div class="col-sm-4 col-md-6 col-lg-6 col-12 d-block text-center my-auto">
            <h1 id="titulo" class="text-white"> Animal ONG</h1>
          </div>
  
          <div class="col-sm-0 col-md-2 col-lg-2 col-0  ">
         
         </div>

        </div>  
        <nav class="navbar navbar-light navbar-expand-lg bg-light mb-3" style="background-color: rgb(205, 248, 253)">
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#conteudoNavbarSuportado" aria-controls="conteudoNavbarSuportado" aria-expanded="false" aria-label="Alterna navegação">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="conteudoNavbarSuportado">
      
          <ul class="navbar-nav mr-auto">
              <li class="nav-item">
                  <a  class="nav-link"  href= <?= base_url('/animal')?>>Página inicial</a>
                </li>
                <li class="nav-item">
          <a class="nav-link" href= <?= base_url('adocao/novo')?>>Adoção</a>
        </li>
              <li class="nav-item">
                <a class="nav-link" href= <?= base_url('doacao/novo') ?>>Doação</a>
              </li>
              <li class="nav-item">
                <a id="ativo"class="nav-link active"  href= <?= base_url('denuncia/novo')?>>Denúncia</a>
              </li>
              <li class="nav-item">
          <?php if (!session()->get('id_usuario')): ?>
            <a class="nav-link " href= <?= base_url('usuario/logar') ?>>Login</a>
          <?php endif; ?>
          
          <?php if (session()->get('id_usuario')): ?>
            <a class="nav-link " href= <?= base_url('usuario/sair') ?>>Sair</a>
            <?php endif; ?>
        </li>
            </ul>
            <form class="form-inline my-2 my-lg-0">
              <input class="form-control mr-sm-2" type="search" placeholder="Pesquisar" aria-label="Pesquisar">
              <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Pesquisar</button>
            </form>
          </div>
      </nav>

        <h3>Faça sua denúncia.</h3>
        <div class="row">
          <div class="col-6">
            <div class="position-center" style="bottom: 0px; left : 0px;">
              <img class="w-100" src="<?= base_url('img/img_denuncia.png') ?>">
          </div>  
          </div> 
          <div class="col-6">
          <?= form_open_multipart('denuncia/novo') ?> 
        <div class="form-group">
          <label for="exampleInputEmail1">Motivo da denúncia e o seu ocorrido</label>
          <input name="motivo" type="text" class="form-control" id="exampleInput" aria-describedby="emailHelp" placeholder="Escreva aqui">
        </div>
        <div class="form-group">
          <label for="exampleInputPassword1">Estado e cidade onde foi localizado os maus tratos</label>
          <input name="endereco" type="text" class="form-control" id="exampleInput" placeholder="Escreva aqui">
        </div>
        <div class="form-group">
            <label for="exampleFormControlFile1">Adicione as fotos e vídeos da sua denúncia</label>            
            <input type="file" class="form-control" id="foto_denuncia" placeholder="" value="<?= $denuncia->foto_denuncia ?>" name="foto_denuncia">
            <small id="emailHelp" class="form-text text-muted">Seus dados não serão compartilhados, eles são anônimos.</small>
        </div>
      
        <button class="btn btn-primary btn-lg btn-block" type="submit">Enviar Denúncia</button>
        <?php if ($sucesso === true) : ?>
                        <div class="alert alert-success" role="alert">
                          Denuncia cadastrada com sucesso!
                        </div>
                    <?php endif; ?>

      
        
      </form>
    </div> 
  </div>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <footer>
      <h3><b>Contato</b></h3>
      <adress>Animal@gmail.com</adress>
    </footer>
  </div>
</body>
</html>