<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Exemplos de Código - CodeIgniter 4</title>
    <meta name="description" content="Exemplos de código para apoiar o conteúdo do livro CodeIgniter 4">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="image/png" href="/favicon.ico" />

    <!-- STYLES -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
</head>

<body>

    <body class="bg-light">

        <div class="container">
            <div class="py-5 text-center">
                <!--
				COLOCAR A ILUSTRAÇÃO DA CAPA DO LIVRO AQUI
				<img class="d-block mx-auto mb-4" src="../../assets/brand/bootstrap-solid.svg" alt="" width="72" height="72">
				-->
                <h2>CRUD</h2>
                <p class="lead">Nesse exemplo você verá como construir um CRUD usando o CodeIgniter 4 e seus recursos nativos.</p>
            </div>

            <div class="row">
                <div class="col-md-4 order-md-2 mb-4">
                    <a href="<?= base_url('usuario') ?>" class="btn btn-success block">Ver Usuários</a>
                    <?php if (count($erros) > 0) : ?>
                        <h4 class="d-flex justify-content-between align-items-center mb-3">
                            <span class="text-muted">Status da Validação</span>
                        </h4>
                        <ul class="list-group mb-3">
                            <?php foreach ($erros as $campo => $erro) : ?>
                                <li class="list-group-item d-flex justify-content-between lh-condensed">
                                    <div>
                                        <h6 class="my-0"><?= $campo ?></h6>
                                        <small class="text-muted"><?= $erro ?></small>
                                    </div>
                                </li>
                            <?php endforeach ?>
                        </ul>
                    <?php endif; ?>
                    <h4 class="d-flex justify-content-between align-items-center mb-3 mt-3">
                        <span class="text-muted">Regras da Validação</span>
                    </h4>
                    <ul class="list-group mb-3">
                        <li class="list-group-item d-flex justify-content-between lh-condensed">
                            <div>
                                <h6 class="my-0">Nome</h6>
                                <small class="text-muted">Obrigatório, mínimo de 3 caracteres</small>
                            </div>
                        </li>
                        <li class="list-group-item d-flex justify-content-between lh-condensed">
                            <div>
                                <h6 class="my-0">cpf</h6>
                                <small class="text-muted">Obrigatório, mínimo de 11 caracteres e maximo 11 caracteres</small>
                            </div>
                        </li>

                    </ul>
                </div>
                <div class="col-md-8 order-md-1">
                    <h4 class="mb-3">Dados Pessoais</h4>
                    <form method="POST">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="primeiroNome">Nome Completo</label>
                                <input type="text" class="form-control" id="nome" placeholder="" value="<?= $usuario->nome ?>" name="nome">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="cpf">CPF</label>
                                <input type="text" class="form-control" id="cpf" placeholder="" value="<?= $usuario->cpf ?>" name="cpf">
                            </div>
                        </div>

                        <hr class="mb-4">
                        <input type="hidden" name="id_usuario" value="<?= $usuario->id_usuario ?>" />
                        <?php if ($sucesso) : ?>
                        <div class="alert alert-success" role="alert">
                            Usuário cadastrado com sucesso!
                        </div>
                    <?php endif; ?>

                    <?php if (!$sucesso) : ?>
                        <button class="btn btn-primary btn-lg btn-block" type="submit">Atualizar Dados</button>
                    <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>

    </body>

</html>