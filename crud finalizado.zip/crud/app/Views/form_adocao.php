<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <!-- Meta tags Obrigatórias -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Exemplos de código para apoiar o conteúdo do livro CodeIgniter 4">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="image/png" href="/favicon.ico" />

     <!-- Bootstrap CSS -->
     <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"  integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
     <link rel="stylesheet" href="ong.css">
     <link rel="stylesheet" href=<?= base_url('css/ong.css') ?>>
     
    <title>Animal ONG</title>
  </head>
  
  <body>
  <?php if ($sucesso) : ?>
                        <div class="alert alert-success" role="alert">
                            Usuário cadastrado com sucesso!
                        </div>
                    <?php endif; ?>
  
    <div class="container ">
      <div class="row" id="cabecalho">
        <div class="col-sm-4 col-md-3 col-lg-3 col-3 ">
          <img class="w-75" src="<?= base_url('img/logo_ong.PNG') ?>" alt="logo do usuário">
        </div>

        <div class="col-sm-4 col-md-6 col-lg-6 col-10 d-block text-center my-auto">
          <h1 id="titulo" class="text-white"> Animal ONG</h1>
        </div>

        <div class="col-sm-0 col-md-2 col-lg-2 col-0  ">
       
       </div>
      </div>  


  <nav class="navbar navbar-light navbar-expand-lg bg-light mb-3" style="background-color: rgb(205, 248, 253)" >
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#conteudoNavbarSuportado" aria-controls="conteudoNavbarSuportado" aria-expanded="false" aria-label="Alterna navegação">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="conteudoNavbarSuportado">

    <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a  class="nav-link" href= <?= base_url('/animal') ?>>Página inicial</a>
              </li>
              <li class="nav-item">
          <a id="ativo" class="nav-link active" href= <?= base_url('adocao/novo')?>>Adoção</a>
        </li>
            <li class="nav-item">
              <a class="nav-link" href= <?= base_url('doacao/novo') ?>>Doação</a>
            </li>
            <li class="nav-item">
              <a class="nav-link " href= <?= base_url('denuncia/novo')?>>Denúncia</a>
            </li>
            <li class="nav-item">
          <?php if (!session()->get('id_usuario')): ?>
            <a class="nav-link " href= <?= base_url('usuario/logar') ?>>Login</a>
          <?php endif; ?>
          
          <?php if (session()->get('id_usuario')): ?>
            <a class="nav-link " href= <?= base_url('usuario/sair') ?>>Sair</a>
            <?php endif; ?>
        </li>
          </ul>
      <form class="form-inline my-2 my-lg-0">
        <input class="form-control mr-sm-2" type="search" placeholder="Pesquisar" aria-label="Pesquisar">
        <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Pesquisar</button>
      </form>
    </div>
</nav>

            <div class="row">

              <div class="col-3">
                  <img class="w-100" src="<?= base_url('img/foto_adocao1.png') ?>">
              </div>
              

        <form class="col-9" method="post" action="<?= base_url('adocao/novo') ?>">
            <div class="form-group">
                <label for="exampleInputPassword1">Telefone</label>
                <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Telefone" name="telefone">
            </div>
            <div class="form-group">
                <label for="exampleInputEmail1">Email</label>
                <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                    placeholder="Seu email" name="email">
            </div>
            <div class="form-group">
                <label>Endereço</label>
                <input type="endereco" class="form-control" id="exampleInputPassword1" placeholder="Endereço" name="endereco">
            </div>
            <div class="form-group">
                <label for="exampleInputPassword1">Usuário</label>
                <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Usuário" name="id_usuario">
            </div>
            <div class="form-group">
                <label for="exampleInputPassword1">Animal</label>

                <select name="id_produto" id="inputEstado" class="form-control">

                <?php foreach ($animais as $animal) : ?>
                 
                  
                  <option value="<?= $animal->id_animal ?>"><?= $animal->nome_animal ?></option>
               					
									<?php endforeach ?>
                  </select>	

                
            </div>
            <small id="emailHelp" class="form-text text-muted">Nunca vamos compartilhar seus dados, com ninguém.</small>
                       
            <p></p>
            <button class="btn btn-primary btn-lg btn-block" type="submit">Enviar Adoção</button>
           
        </form>
    </div>
    <footer>
      <h3><b>Contato</b></h3>
      <adress>AmandaPizza@gmail.com</adress>
  </footer>

        <!-- JavaScript (Opcional) -->
        <!-- jQuery primeiro, depois Popper.js, depois Bootstrap JS -->
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
            integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
            crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"
            integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
            crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"
            integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy"
            crossorigin="anonymous"></script>
    </div>
</body>

</html>