<?php

namespace App\Entities;

use CodeIgniter\Entity\Entity;
use CodeIgniter\I18n\Time;

class Doacao extends Entity
{
    // Definimos os atributos de acordo com as colunas existentes na tabela usuarios
    protected $attributes = [
        'email' => null,
        'senha'        => null,
        'id_produto' => null,
        'id_usuario' => null
    ];

    // Definimos os campos que recebem as informações de data referentes a criação, atualização e exclusão
    protected $dates = ['criado_em', 'atualizado_em', 'removido_em'];

}
