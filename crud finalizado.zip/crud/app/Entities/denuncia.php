<?php

namespace App\Entities;

use CodeIgniter\Entity\Entity;
use CodeIgniter\I18n\Time;

class Denuncia extends Entity
{
    // Definimos os atributos de acordo com as colunas existentes na tabela usuarios
    protected $attributes = [
        'endereco'          => null,
        'motivo'            => null,
        'foto_denuncia'     =>null
    ];


}
