<?php

namespace App\Entities;

use CodeIgniter\Entity\Entity;
use CodeIgniter\I18n\Time;

class Fotos extends Entity
{
    // Definimos os atributos de acordo com as colunas existentes na tabela usuarios
    protected $attributes = [
        'id_fotos'             => null,
        'link'                 => null,
        'id_animal'            => null,
        'id_denuncia'            => null
    ];

}
