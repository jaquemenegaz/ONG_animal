<?php

namespace App\Entities;

use CodeIgniter\Entity\Entity;
use CodeIgniter\I18n\Time;

class Animal extends Entity
{
    // Definimos os atributos de acordo com as colunas existentes na tabela usuarios
    protected $attributes = [
        'nome_animal'     =>null,
        'caracteristicas' => null,
        'raca'            => null,
        'foto_animal'     =>null
    ];


}
