<?php

namespace App\Entities;

use CodeIgniter\Entity\Entity;
use CodeIgniter\I18n\Time;

class Usuario extends Entity
{
    // Definimos os atributos de acordo com as colunas existentes na tabela usuarios
    protected $attributes = [
        'email'             => null,
        'senha'              => null
    ];
}
