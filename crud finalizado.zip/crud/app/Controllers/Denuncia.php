<?php

namespace App\Controllers;

use CodeIgniter\Files\File;

class Denuncia extends BaseController
{
	private $uModel;
	protected $helpers = ['form'];

	public function __construct()
	{
		// Criamos uma instância do model
		$this->uModel = new \App\Models\DenunciaModel();
	}

	public function index()
	{
		// Estruturamos o array que envia as informações para view
		// Recuperando todos os registros da tabela usuarios
		// Organizados já na estrutura de paginação nativa do CodeIgniter 4
		$dados = [
			'animais'  => $this->uModel->paginate(100),
			'paginacao' => $this->uModel->pager, // Estrutura de paginação (links)
			'sessao'    => $this->session
		];

		// Carregamos a view
		return view('index', $dados);
	}

	public function novo()
	{
		// Estruturamos o array que envia as informações para view
		// Recuperando as informações da entidade Usuario
		$dados = [
			'sessao'   => $this->session,
			'sucesso' => ($this->request->getMethod() === 'post') ? true : false,
			'erros'   => [],
			'denuncia' => new \App\Entities\Denuncia()
		];

		// Verificamos se o formulário foi submetido
		if ($this->request->getPost()) {
			// Criamos uma nova entidade Usuario que receberá os dados enviados
			// através do formulário para que sejam devidamente formatados e estruturados
			// para então serem salvos no banco de dados
			$denuncia   = new \App\Entities\Denuncia();

			// Recuperamos os dados enviados pelo formulário
			$dtDenuncia = $this->request->getPost();

			$img = $this->request->getFile('foto_denuncia');

			if ( !$img->hasMoved() ) {
				$foto_denuncia = rand(1,1000).$img->getName();
				//$filepath = WRITEPATH . 'uploads/' . $img->store();
				
				//$data = ['uploaded_fileinfo' => new File($filepath)];
				$img->move(ROOTPATH . 'public/uploads/', $foto_denuncia);
			}


			$dtDenuncia['foto_denuncia'] = $foto_denuncia;

			// Salvamos os registros na tabela 'usuarios' utilizando os recursos da entidade
			// Usuario para estruturar e formatar os dados para então salvar no banco de dados
			// e em caso de erroretornamos os mesmos para a variável 'dados' para serem exibidos
			// na view
			if ($this->uModel->save($denuncia->fill($dtDenuncia)) === false) {
				$dados['sucesso'] = false;
				$dados['erros']   = $this->uModel->errors();
				$dados['denuncia'] = $denuncia;
			} else {
				$dados['sucesso'] = true;
			}
		}

		// Carregamos a view
		return view('denuncia', $dados);
	}

	public function editar($id_denuncia = null)
	{
		// Recuperamos as informações do usuário
		$denuncia = $this->uModel->find($id_denuncia);

		// Verificamos se foi encontrado um usuário com o ID informado
		// Se não retornou nenhum usuário, então redirecionamos para a página principal
		if (is_null($denuncia)) {
			$this->session->setFlashdata('msgWarning', 'Nenhuma denúncia encontrado para edição.');
			return redirect()->to(base_url());
		}

		// Estruturamos o array que envia as informações para view
		$dados = [
			'sessao'   => $this->session,
			'sucesso' => ($this->request->getMethod() === 'post') ? true : false,
			'erros'   => [],
			'denuncia' => $denuncia
		];

		// Verificamos se o formulário foi submetido
		if ($this->request->getPost()) {
			// Recuperamos os dados enviados pelo formulário
			$dtDenuncia = $this->request->getPost();

			// Salvamos os registros na tabela 'usuarios' e em caso de erro
			// retornamos os mesmos para a variável 'dados' para serem exibidos
			// na view
			if ($this->uModel->save($denuncia->fill($dtDenuncia)) === false) {
				$dados['sucesso'] = false;
				$dados['erros']   = $this->uModel->errors();
			} else {
				$dados['sucesso'] = true;
			}

		}

		// Carregamos a view
		return view('editar_denuncia', $dados);
	}

	public function excluir($id_denuncia = null)
	{
		// Recuperamos as informações do usuário
		$denuncia = $this->uModel->find($id_denuncia);
		// Definimos mensagem padrão para o caso de erro na exclusão do usuário
		$this->session->setFlashdata('msgWarning', 'Não foi possível excluir a denúncia.');

		// Verificamos se foi encontrado um usuário com o ID informado
		// Se não retornou nenhum usuário, então redirecionamos para a página principal
		// Com uma mensagem a ser exibida
		if (is_null($denuncia)) {
			$this->session->setFlashdata('msgWarning', 'Nenhuma denúncia encontrado para excluir.');
			return redirect()->to(base_url());
		}

		// Executamos a exclusão do usuário
		// E se executar com sucesso, definimos a mensagem de sucesso
		if ($this->uModel->delete(['id' => $id_denuncia])) {
			$this->session->setFlashdata('msgWarning', 'Denúncia excluído com sucesso.');
		}

		// Redirecionamos para página principal
		return redirect()->to(base_url('denuncia/'));
	}
}
