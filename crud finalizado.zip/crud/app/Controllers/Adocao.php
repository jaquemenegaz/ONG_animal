<?php

namespace App\Controllers;

//use CodeIgniter\Files\File;

class Adocao extends BaseController
{
	private $uModel;
	private $aModel;
	protected $helpers = ['form'];

	public function __construct()
	{
		// Criamos uma instância do model
		$this->uModel = new \App\Models\AdocaoModel();
		$this->aModel = new \App\Models\AnimalModel();
	}

	public function index()
	{

		if (!session()->get('id_usuario')) {
			return redirect()->to('/usuario/novo');
			}	
		// Estruturamos o array que envia as informações para view
		// Recuperando todos os registros da tabela usuarios
		// Organizados já na estrutura de paginação nativa do CodeIgniter 4
		$dados = [
			'adocao'  => $this->uModel->paginate(100),
			'paginacao' => $this->uModel->pager, // Estrutura de paginação (links)
			'sessao'    => $this->session
		];

		// Carregamos a view
		return view('index', $dados);
	}

	public function novo()
	{
		
		if (!session()->get('id_usuario')) {
			return redirect()->to('usuario/logar');
		}
		// Estruturamos o array que envia as informações para view
		// Recuperando as informações da entidade Usuario
		$dados = [
			'sessao'   => $this->session,
			'sucesso' => ($this->request->getMethod() === 'post') ? true : false,
			'erros'   => [],
			'adocao' => new \App\Entities\Adocao(),
			'animais' => $this->aModel->findAll()
		];

		// Verificamos se o formulário foi submetido
		if ($this->request->getPost()) {
			// Criamos uma nova entidade Usuario que receberá os dados enviados
			// através do formulário para que sejam devidamente formatados e estruturados
			// para então serem salvos no banco de dados
			$adocao   = new \App\Entities\Adocao();

			// Recuperamos os dados enviados pelo formulário
			$dtAdocao = $this->request->getPost();

			//$img = $this->request->getFile('adocao');

			/*if ( !$img->hasMoved() ) {
				$adocaoimg = $img->getName();
				$filepath = WRITEPATH . 'uploads/' . $img->store();
				
				//$data = ['uploaded_fileinfo' => new File($filepath)];
				//$img->move(WRITEPATH . 'uploads/', $link);
			}*/


			// Salvamos os registros na tabela 'usuarios' utilizando os recursos da entidade
			// Usuario para estruturar e formatar os dados para então salvar no banco de dados
			// e em caso de erroretornamos os mesmos para a variável 'dados' para serem exibidos
			// na view
			if ($this->uModel->save($adocao->fill($dtAdocao)) === false) {
				$dados['sucesso'] = false;
				$dados['erros']   = $this->uModel->errors();
				$dados['adocao'] = $adocao;
			} else {
				$dados['sucesso'] = true;
			}
		}

		// Carregamos a view
		return view('form_adocao', $dados);
	}

	public function editar($id_adocao = null)
	{
		// Recuperamos as informações do usuário
		$adocao = $this->uModel->find($id_adocao);

		// Verificamos se foi encontrado um usuário com o ID informado
		// Se não retornou nenhum usuário, então redirecionamos para a página principal
		if (is_null($adocao)) {
			$this->session->setFlashdata('msgWarning', 'Nenhuma adoção encontrado para edição.');
			return redirect()->to(base_url());
		}

		// Estruturamos o array que envia as informações para view
		$dados = [
			'sessao'   => $this->session,
			'sucesso' => ($this->request->getMethod() === 'post') ? true : false,
			'erros'   => [],
			'adocao' => $adocao
		];

		// Verificamos se o formulário foi submetido
		if ($this->request->getPost()) {
			// Recuperamos os dados enviados pelo formulário
			$dtAdocao = $this->request->getPost();

			// Salvamos os registros na tabela 'usuarios' e em caso de erro
			// retornamos os mesmos para a variável 'dados' para serem exibidos
			// na view
			if ($this->uModel->save($adocao->fill($dtAdocao)) === false) {
				$dados['sucesso'] = false;
				$dados['erros']   = $this->uModel->errors();
			} else {
				$dados['sucesso'] = true;
			}

		}

	}

	public function excluir($id_adocao = null)
	{
		// Recuperamos as informações do usuário
		$adocao = $this->uModel->find($id_adocao);
		// Definimos mensagem padrão para o caso de erro na exclusão do usuário
		$this->session->setFlashdata('msgWarning', 'Não foi possível excluir a adoção.');

		// Verificamos se foi encontrado um usuário com o ID informado
		// Se não retornou nenhum usuário, então redirecionamos para a página principal
		// Com uma mensagem a ser exibida
		if (is_null($adocao)) {
			$this->session->setFlashdata('msgWarning', 'Nenhuma adoção encontrado para excluir.');
			return redirect()->to(base_url());
		}

		// Executamos a exclusão do usuário
		// E se executar com sucesso, definimos a mensagem de sucesso
		if ($this->uModel->delete(['id' => $id_adocao])) {
			$this->session->setFlashdata('msgWarning', 'Adoção excluído com sucesso.');
		}

		// Redirecionamos para página principal
		return redirect()->to(base_url('adocao/novo'));
	}
}

