<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
//$routes->get('/', 'Usuario::index');

/*
$routes->get('/', 'Usuario::index');
$routes->get('/novo', 'Usuario::novo');
$routes->post('/novo', 'Usuario::novo');
$routes->get('/editar/(:num)', 'Usuario::editar/$1');
$routes->post('/editar/(:num)', 'Usuario::editar/$1');
$routes->get('/excluir/(:num)', 'Usuario::excluir/$1');
*/

$routes->get('/animal', 'Animal::indexPublico');
$routes->get('/animal/novo', 'Animal::novo');
$routes->post('/animal/novo', 'Animal::novo');
$routes->get('/animal/editar/(:num)', 'Animal::editar/$1');
$routes->post('/animal/editar/(:num)', 'Animal::editar/$1');
$routes->get('/animal/excluir/(:num)', 'Animal::excluir/$1');

$routes->get('/usuario', 'Usuario::usuario');
$routes->get('/usuario/novo', 'Usuario::novo');
$routes->post('/usuario/novo', 'Usuario::novo');
$routes->get('/usuario/editar/(:num)', 'Usuario::editar/$1');
$routes->post('/usuario/editar/(:num)', 'Usuario::editar/$1');
$routes->get('/usuario/excluir/(:num)', 'Usuario::excluir/$1');
$routes->get('/usuario/logar', 'Usuario::logar');
$routes->post('/usuario/login', 'Usuario::login');
$routes->get('/usuario/sair', 'Usuario::logout');

$routes->get('/fotos', 'fotos::index');
$routes->get('/fotos/novo', 'fotos::novo');
$routes->post('/fotos/novo', 'fotos::novo');
$routes->get('/fotos/excluir/(:num)', 'fotos::excluir/$1');

$routes->get('/doacao', 'Doacao::doacao');
$routes->get('/doacao/novo', 'Doacao::novo');
$routes->post('/doacao/novo', 'Doacao::novo');
$routes->get('/doacao/editar/(:num)', 'Doacao::editar/$1');
$routes->post('/doacao/editar/(:num)', 'Doacao::editar/$1');
$routes->get('/doacao/excluir/(:num)', 'Doacao::excluir/$1');

$routes->get('/denuncia', 'Denuncia::denuncia');
$routes->get('/denuncia/novo', 'Denuncia::novo');
$routes->post('/denuncia/novo', 'Denuncia::novo');
$routes->get('/denuncia/editar/(:num)', 'Denuncia::editar/$1');
$routes->post('/denuncia/editar/(:num)', 'Denuncia::editar/$1');
$routes->get('/denuncia/excluir/(:num)', 'Denuncia::excluir/$1');

$routes->get('/adocao', 'Adocao::adocao');
$routes->get('/adocao/novo', 'Adocao::novo');
$routes->post('/adocao/novo', 'Adocao::novo');
$routes->get('/adocao/excluir/(:num)', 'Adocao::excluir/$1');